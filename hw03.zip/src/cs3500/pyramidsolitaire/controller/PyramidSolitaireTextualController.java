package cs3500.pyramidsolitaire.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.view.PyramidSolitaireTextualView;

public class PyramidSolitaireTextualController implements PyramidSolitaireController {
  private final Readable rd;
  private final Appendable ap;

  public PyramidSolitaireTextualController(Readable rd, Appendable ap)
          throws IllegalArgumentException {
    if (rd == null
            || ap == null) {
      throw new IllegalArgumentException("The Readable and Appendable cannot be null.");
    }
    this.rd = rd;
    this.ap = ap;
  }

  @Override
  public <K> void playGame(PyramidSolitaireModel<K> model, List<K> deck, boolean shuffle,
                           int numRows, int numDraw) {
    if (model == null) {
      throw new IllegalArgumentException("The model cannot be null.");
    }
    try {
      model.startGame(deck, shuffle, numRows, numDraw);
      Scanner scan = new Scanner(this.rd);
      String strInput = "";
      int[] theseInputs;
      int num1;
      int num2;
      int num3;
      int num4;
      while (scan.hasNext()) {
        boolean exceptionThrownDoNotPrint = false;
        strInput = scan.next();
        switch (strInput) {
          case "rm1":
            theseInputs = getInputs(2, scan, model);
            //signal that the user has quit the game in the inputs
            if (theseInputs.length == 10) {
              break;
            }
            num1 = theseInputs[0] - 1;
            num2 = theseInputs[1] - 1;
            try {
              model.remove(num1, num2);
            } catch (IllegalArgumentException e) {
              this.ap.append("Invalid move. Play again. Remove not valid.\n");
              exceptionThrownDoNotPrint = true;
            }
            break;
          case "rm2":
            theseInputs = getInputs(4, scan, model);
            if (theseInputs.length == 10) {
              break;
            }
            num1 = theseInputs[0] - 1;
            num2 = theseInputs[1] - 1;
            num3 = theseInputs[2] - 1;
            num4 = theseInputs[3] - 1;
            try {
              model.remove(num1, num2, num3, num4);
            } catch (IllegalArgumentException e) {
              this.ap.append("Invalid move. Play again. Remove not valid.\n");
              exceptionThrownDoNotPrint = true;
            }
            break;
          case "rmwd":
            theseInputs = getInputs(3, scan, model);
            if (theseInputs.length == 10) {
              break;
            }
            num1 = theseInputs[0] - 1;
            num2 = theseInputs[1] - 1;
            num3 = theseInputs[2] - 1;
            try {
              model.removeUsingDraw(num1, num2, num3);
            } catch (IllegalArgumentException e) {
              this.ap.append("Invalid move. Play again. Remove with draw not valid.\n");
              exceptionThrownDoNotPrint = true;
            }
            break;
          case "dd":
            theseInputs = getInputs(1, scan, model);
            if (theseInputs.length == 10) {
              break;
            }
            num1 = theseInputs[0] - 1;
            try {
              model.discardDraw(num1);
            } catch (IllegalArgumentException e) {
              this.ap.append("Invalid move. Play again. Discard draw not valid.\n");
              exceptionThrownDoNotPrint = true;
            }
            break;
          case "q":
          case "Q":
            this.ap.append("Game quit!\n"
                    + "State of game when quit:\n");
            break;
        }
        if (!exceptionThrownDoNotPrint) {
          renderMove(model);
          if (!(model.isGameOver() || model.getScore() == 0)) {
            this.ap.append("\nScore: " + model.getScore() + "\n");
          }
        }
      }
    } catch (IOException io) {
      throw new IllegalStateException("the Appendable object is unable to transmit output " +
              "or the Readable object is unable to provide inputs.");
    }
  }

  private void returnQuit(PyramidSolitaireModel m) throws IOException {
    this.ap.append("Game quit!\n"
            + "State of game when quit:\n");
  }

  private void renderMove(PyramidSolitaireModel m) throws IOException {
    PyramidSolitaireTextualView view = new PyramidSolitaireTextualView(m, this.ap);
    view.render();
  }

  /**
   * private void handleRm1(Scanner scan, PyramidSolitaireModel model) throws IOException { if
   * (scan.hasNext() && scan.hasNextInt()) { int card1 = scan.nextInt() - 1; if (scan.hasNext() &&
   * scan.hasNextInt()) { int card2 = scan.nextInt() - 1; } } else if (scan.hasNext()) { String
   * other = scan.next(); if (hasQuit(other)) { returnQuit(model); } else { findNextValidInput(scan,
   * "rm1"); } } }
   **/
  private int[] getInputs(int numInputs, Scanner scan, PyramidSolitaireModel m) throws IOException {
    int soFar = 0;
    int[] myIntArray = new int[numInputs];
    while (soFar < numInputs) {
      if (!scan.hasNext()) {
        throw new IllegalStateException("Readable has run out before move could be completed.");
      } else {
        if (scan.hasNextInt()) {
          myIntArray[soFar] = scan.nextInt();
          soFar += 1;
        } else {
          String s = scan.next();
          if (s.equals("q") || s.equals("Q")) {
            returnQuit(m);
            //signal for the method to quit the game
            return new int[10];
          } else {
            this.ap.append("Please re-enter a valid input.\n");
          }
        }
      }
    }
    return myIntArray;
  }

  private void checkIfFailedToQuit(Scanner scan) {
    if (!scan.hasNext()) {
      throw new IllegalStateException("User did not enter enough input to complete/quit game.");
    }
  }
}
