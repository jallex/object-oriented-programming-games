package cs3500.pyramidsolitaire.model.hw02;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.theories.suppliers.TestedOn;

import cs3500.pyramidsolitaire.controller.PyramidSolitaireTextualController;

import static org.junit.Assert.assertEquals;

public class BasicPyramidSolitaireControllerTest {
  BasicPyramidSolitaire bps = new BasicPyramidSolitaire();
  List<ICard> deck1;
  List<ICard> deck2;
  List<ICard> deck3;
  Random rand = new Random();

  @Before
  public void setUp() throws Exception {
    this.deck1 = new ArrayList<ICard>();
    deck1.add(new Card(1, Type.HEARTS));
    deck1.add(new Card(1, Type.CLUBS));
    deck1.add(new Card(1, Type.DIAMONDS));
    deck1.add(new Card(1, Type.SPADES));
    deck1.add(new Card(2, Type.HEARTS));
    deck1.add(new Card(2, Type.CLUBS));
    deck1.add(new Card(10, Type.DIAMONDS));
    deck1.add(new Card(10, Type.SPADES));
    deck1.add(new Card(3, Type.HEARTS));
    deck1.add(new Card(13, Type.CLUBS));
    deck1.add(new Card(3, Type.DIAMONDS));
    deck1.add(new Card(3, Type.SPADES));
    deck1.add(new Card(4, Type.HEARTS));
    deck1.add(new Card(4, Type.CLUBS));
    deck1.add(new Card(4, Type.DIAMONDS));
    deck1.add(new Card(4, Type.SPADES));
    deck1.add(new Card(5, Type.HEARTS));
    deck1.add(new Card(5, Type.CLUBS));
    deck1.add(new Card(5, Type.DIAMONDS));
    deck1.add(new Card(5, Type.SPADES));
    deck1.add(new Card(6, Type.HEARTS));
    deck1.add(new Card(6, Type.CLUBS));
    deck1.add(new Card(6, Type.DIAMONDS));
    deck1.add(new Card(6, Type.SPADES));
    deck1.add(new Card(7, Type.HEARTS));
    deck1.add(new Card(7, Type.CLUBS));
    deck1.add(new Card(7, Type.DIAMONDS));
    deck1.add(new Card(7, Type.SPADES));
    deck1.add(new Card(8, Type.HEARTS));
    deck1.add(new Card(8, Type.CLUBS));
    deck1.add(new Card(8, Type.DIAMONDS));
    deck1.add(new Card(8, Type.SPADES));
    deck1.add(new Card(9, Type.HEARTS));
    deck1.add(new Card(9, Type.CLUBS));
    deck1.add(new Card(9, Type.DIAMONDS));
    deck1.add(new Card(9, Type.SPADES));
    deck1.add(new Card(10, Type.HEARTS));
    deck1.add(new Card(10, Type.CLUBS));
    deck1.add(new Card(2, Type.DIAMONDS));
    deck1.add(new Card(2, Type.SPADES));
    deck1.add(new Card(11, Type.HEARTS));
    deck1.add(new Card(11, Type.CLUBS));
    deck1.add(new Card(11, Type.DIAMONDS));
    deck1.add(new Card(11, Type.SPADES));
    deck1.add(new Card(12, Type.HEARTS));
    deck1.add(new Card(12, Type.CLUBS));
    deck1.add(new Card(12, Type.DIAMONDS));
    deck1.add(new Card(12, Type.SPADES));
    deck1.add(new Card(13, Type.HEARTS));
    deck1.add(new Card(3, Type.CLUBS));
    deck1.add(new Card(13, Type.DIAMONDS));
    deck1.add(new Card(13, Type.SPADES));

    this.deck2 = new ArrayList<ICard>();
    deck2.add(new Card(3, Type.HEARTS));
    deck2.add(new Card(10, Type.CLUBS));
    deck2.add(new Card(1, Type.HEARTS));
    deck2.add(new Card(1, Type.CLUBS));
    deck2.add(new Card(1, Type.DIAMONDS));
    deck2.add(new Card(1, Type.SPADES));
    deck2.add(new Card(2, Type.HEARTS));
    deck2.add(new Card(2, Type.CLUBS));
    deck2.add(new Card(10, Type.DIAMONDS));
    deck2.add(new Card(10, Type.SPADES));
    deck2.add(new Card(13, Type.CLUBS));
    deck2.add(new Card(3, Type.DIAMONDS));
    deck2.add(new Card(3, Type.SPADES));
    deck2.add(new Card(4, Type.HEARTS));
    deck2.add(new Card(4, Type.CLUBS));
    deck2.add(new Card(4, Type.DIAMONDS));
    deck2.add(new Card(4, Type.SPADES));
    deck2.add(new Card(5, Type.HEARTS));
    deck2.add(new Card(5, Type.CLUBS));
    deck2.add(new Card(5, Type.DIAMONDS));
    deck2.add(new Card(5, Type.SPADES));
    deck2.add(new Card(6, Type.HEARTS));
    deck2.add(new Card(6, Type.CLUBS));
    deck2.add(new Card(6, Type.DIAMONDS));
    deck2.add(new Card(6, Type.SPADES));
    deck2.add(new Card(7, Type.HEARTS));
    deck2.add(new Card(7, Type.CLUBS));
    deck2.add(new Card(7, Type.DIAMONDS));
    deck2.add(new Card(7, Type.SPADES));
    deck2.add(new Card(8, Type.HEARTS));
    deck2.add(new Card(8, Type.CLUBS));
    deck2.add(new Card(8, Type.DIAMONDS));
    deck2.add(new Card(8, Type.SPADES));
    deck2.add(new Card(9, Type.HEARTS));
    deck2.add(new Card(9, Type.CLUBS));
    deck2.add(new Card(9, Type.DIAMONDS));
    deck2.add(new Card(9, Type.SPADES));
    deck2.add(new Card(10, Type.HEARTS));
    deck2.add(new Card(2, Type.DIAMONDS));
    deck2.add(new Card(2, Type.SPADES));
    deck2.add(new Card(11, Type.HEARTS));
    deck2.add(new Card(11, Type.CLUBS));
    deck2.add(new Card(11, Type.DIAMONDS));
    deck2.add(new Card(11, Type.SPADES));
    deck2.add(new Card(12, Type.HEARTS));
    deck2.add(new Card(12, Type.CLUBS));
    deck2.add(new Card(12, Type.DIAMONDS));
    deck2.add(new Card(12, Type.SPADES));
    deck2.add(new Card(13, Type.HEARTS));
    deck2.add(new Card(3, Type.CLUBS));
    deck2.add(new Card(13, Type.DIAMONDS));
    deck2.add(new Card(13, Type.SPADES));

    this.deck3 = new ArrayList<ICard>();
    deck3.add(new Card(10, Type.CLUBS));
    deck3.add(new Card(1, Type.CLUBS));
    deck3.add(new Card(3, Type.CLUBS));
    deck3.add(new Card(10, Type.HEARTS));
    deck3.add(new Card(12, Type.HEARTS));
    deck3.add(new Card(12, Type.CLUBS));
    deck3.add(new Card(12, Type.DIAMONDS));
    deck3.add(new Card(12, Type.SPADES));
    deck3.add(new Card(3, Type.DIAMONDS));
    deck3.add(new Card(3, Type.SPADES));
    deck3.add(new Card(3, Type.HEARTS));
    deck3.add(new Card(1, Type.HEARTS));
    deck3.add(new Card(1, Type.DIAMONDS));
    deck3.add(new Card(1, Type.SPADES));
    deck3.add(new Card(2, Type.HEARTS));
    deck3.add(new Card(2, Type.CLUBS));
    deck3.add(new Card(10, Type.DIAMONDS));
    deck3.add(new Card(10, Type.SPADES));
    deck3.add(new Card(13, Type.CLUBS));
    deck3.add(new Card(4, Type.HEARTS));
    deck3.add(new Card(4, Type.CLUBS));
    deck3.add(new Card(4, Type.DIAMONDS));
    deck3.add(new Card(4, Type.SPADES));
    deck3.add(new Card(5, Type.HEARTS));
    deck3.add(new Card(5, Type.CLUBS));
    deck3.add(new Card(5, Type.DIAMONDS));
    deck3.add(new Card(5, Type.SPADES));
    deck3.add(new Card(6, Type.HEARTS));
    deck3.add(new Card(6, Type.CLUBS));
    deck3.add(new Card(6, Type.DIAMONDS));
    deck3.add(new Card(6, Type.SPADES));
    deck3.add(new Card(7, Type.HEARTS));
    deck3.add(new Card(7, Type.CLUBS));
    deck3.add(new Card(7, Type.DIAMONDS));
    deck3.add(new Card(7, Type.SPADES));
    deck3.add(new Card(8, Type.HEARTS));
    deck3.add(new Card(8, Type.CLUBS));
    deck3.add(new Card(8, Type.DIAMONDS));
    deck3.add(new Card(8, Type.SPADES));
    deck3.add(new Card(9, Type.HEARTS));
    deck3.add(new Card(9, Type.CLUBS));
    deck3.add(new Card(9, Type.DIAMONDS));
    deck3.add(new Card(9, Type.SPADES));
    deck3.add(new Card(2, Type.DIAMONDS));
    deck3.add(new Card(2, Type.SPADES));
    deck3.add(new Card(11, Type.HEARTS));
    deck3.add(new Card(11, Type.CLUBS));
    deck3.add(new Card(11, Type.DIAMONDS));
    deck3.add(new Card(11, Type.SPADES));
    deck3.add(new Card(13, Type.HEARTS));
    deck3.add(new Card(13, Type.DIAMONDS));
    deck3.add(new Card(13, Type.SPADES));

  }


  private void testRun(PyramidSolitaireModel model, Interaction... interactions) throws IOException {
    StringBuilder fakeUserInput = new StringBuilder();
    StringBuilder expectedOutput = new StringBuilder();

    for (Interaction interaction : interactions) {
      interaction.apply(fakeUserInput, expectedOutput);
    }

    StringReader input = new StringReader(fakeUserInput.toString());
    StringBuilder actualOutput = new StringBuilder();

    PyramidSolitaireTextualController controller = new PyramidSolitaireTextualController(input, actualOutput);
    controller.playGame(model, this.deck1, false, 4, 2);

    assertEquals(expectedOutput.toString(), actualOutput.toString());
  }

  //User Won the game
  private void testRunWinGame(PyramidSolitaireModel model, Interaction... interactions) throws IOException {
    StringBuilder fakeUserInput = new StringBuilder();
    StringBuilder expectedOutput = new StringBuilder();

    for (Interaction interaction : interactions) {
      interaction.apply(fakeUserInput, expectedOutput);
    }

    StringReader input = new StringReader(fakeUserInput.toString());
    StringBuilder actualOutput = new StringBuilder();

    PyramidSolitaireTextualController controller = new PyramidSolitaireTextualController(input, actualOutput);
    controller.playGame(model, this.deck2, false, 1, 1);

    assertEquals(expectedOutput.toString(), actualOutput.toString());
  }

  //No more moves left in the game
  private void testRunLoseGame(PyramidSolitaireModel model, Interaction... interactions) throws IOException {
    StringBuilder fakeUserInput = new StringBuilder();
    StringBuilder expectedOutput = new StringBuilder();

    for (Interaction interaction : interactions) {
      interaction.apply(fakeUserInput, expectedOutput);
    }

    StringReader input = new StringReader(fakeUserInput.toString());
    StringBuilder actualOutput = new StringBuilder();

    PyramidSolitaireTextualController controller = new PyramidSolitaireTextualController(input, actualOutput);
    controller.playGame(model, this.deck3, false, 2, 48);

    assertEquals(expectedOutput.toString(), actualOutput.toString());
  }

  @Test
  public void testRemove() throws IOException {
    Interaction[] remove1Card = new Interaction[]{
            new InputInteraction("rm1 "),
            new InputInteraction("4 "),
            new InputInteraction("4 "),
            new PrintInteraction("      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦ 10♠ 3♥\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 31"),
            new InputInteraction("rm2 "),
            new InputInteraction("4 "),
            new InputInteraction("2 "),
            new InputInteraction("4 "),
            new InputInteraction("3 "),
            new PrintInteraction("      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 18"),
            new InputInteraction("rmwd "),
            new InputInteraction("1 "),
            new InputInteraction("4 "),
            new InputInteraction("1 "),
            new PrintInteraction("      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "\n" +
                    "Draw: 4♥, 3♠\n" +
                    "Score: 8"),
            new InputInteraction("dd "),
            new InputInteraction("1 "),
            new PrintInteraction("      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "\n" +
                    "Draw: 4♣, 3♠\n" +
                    "Score: 8"),
            new InputInteraction("q"),
            new PrintInteraction("Game quit!\n" +
                    "State of game when quit:\n" +
                    "      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "\n" +
                    "Draw: 4♣, 3♠\n" +
                    "Score: 8")
    };

    testRun(this.bps, remove1Card);
  }

  @Test
  public void testRemoveException() throws IOException {
    Interaction[] discardDraw = new Interaction[]{
            new InputInteraction("dd"),
            new InputInteraction("4"),
            new PrintInteraction("Invalid move. Play again. Discard draw not valid."),
            new InputInteraction("q"),
            new PrintInteraction("Game quit!\n" +
                    "State of game when quit:\n" +
                    "      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦ 10♠ 3♥  K♣\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 44")
    };
    testRun(this.bps, discardDraw);
  }

  @Test
  public void testGameWon() throws IOException {
//if the game is won
    Interaction[] removeLast = new Interaction[]{
            new InputInteraction("rmwd"),
            new InputInteraction("1"),
            new InputInteraction("1"),
            new InputInteraction("1"),
            new PrintInteraction("You win!")};
    testRunWinGame(this.bps, removeLast);
  }

  @Test
  public void testGameOver() throws IOException {
//if there are no more moves left to be played
    Interaction[] removeLastPossible = new Interaction[]{
            new InputInteraction("rmwd"),
            new InputInteraction("1"),
            new InputInteraction("2"),
            new InputInteraction("2"),
            new InputInteraction("dd 1"),
            new InputInteraction("dd 2"),
            new InputInteraction("dd 3"),
            new InputInteraction("dd 4"),
            new InputInteraction("dd 5"),
            new InputInteraction("dd 6"),
            new InputInteraction("dd 7"),
            new InputInteraction("dd 8"),
            new InputInteraction("dd 9"),
            new PrintInteraction("Game over. Score: 11")};

    testRunLoseGame(this.bps, removeLastPossible);
  }

  @Test
  public void testGameQuit() throws IOException {
    //if the user quits
    Interaction[] quitq = new Interaction[]{
            new InputInteraction("q"),
            new PrintInteraction("Game quit!\n" +
                    "State of game when quit:\n" +
                    "      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦ 10♠ 3♥  K♣\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 44"
            )};

    testRun(this.bps, quitq);
  }

  @Test
  public void testGameQuit2() throws IOException {
    //if user quits in the beginning of a move
    Interaction[] quitQ = new Interaction[]{
            new InputInteraction("Q"),
            new PrintInteraction("Game quit!\n" +
                    "State of game when quit:\n" +
                    "      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦ 10♠ 3♥  K♣\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 44"
            )};

    testRun(this.bps, quitQ);
  }

  @Test
  public void testGameQuit3() throws IOException {
    //if user quits in the beginning of a move
    Interaction[] quitQ = new Interaction[]{
            new InputInteraction("rm1 "),
            new InputInteraction("Q "),
            new PrintInteraction("Game quit!\n" +
                    "State of game when quit:\n" +
                    "      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦ 10♠ 3♥  K♣\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 44")};

    testRun(this.bps, quitQ);
  }


  @Test
  public void testGameQuit5() throws IOException {
    //if user quits in the middle parameter of a move
    Interaction[] quitQ = new Interaction[]{
            new InputInteraction("rm2 "),
            new InputInteraction("1"),
            new InputInteraction("4 "),
            new InputInteraction("Q "),
            new PrintInteraction("Game quit!\n" +
                    "State of game when quit:\n" +
                    "      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦ 10♠ 3♥  K♣\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 44")};

    testRun(this.bps, quitQ);
  }

  @Test
  public void testGameQuit4() throws IOException {
    //if user quits at the end of a move
    Interaction[] quitQ = new Interaction[]{
            new InputInteraction("rm2 "),
            new InputInteraction("1"),
            new InputInteraction("4 "),
            new InputInteraction("1 "),
            new InputInteraction("Q "),
            new PrintInteraction("Game quit!\n" +
                    "State of game when quit:\n" +
                    "      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦ 10♠ 3♥  K♣\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 44")};
    testRun(this.bps, quitQ);
  }


  @Test
  public void testInvalid1() throws IOException {
    //if user types input other than q, Q, or a number
    Interaction[] invalid1 = new Interaction[]{
            new InputInteraction("rm1"),
            new InputInteraction("j"),
            new PrintInteraction("Please re-enter a valid input."),
            new InputInteraction("s"),
            new PrintInteraction("Please re-enter a valid input."),
            new InputInteraction("4"),
            new InputInteraction("4"),
            new PrintInteraction("      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦ 10♠ 3♥\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 31"),
            new InputInteraction("q"),
            new PrintInteraction("Game quit!\n" +
                    "State of game when quit:\n" +
                    "      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦ 10♠ 3♥\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 31")
    };

    testRun(this.bps, invalid1);

    Interaction[] invalid2 = new Interaction[]{
            new InputInteraction("rm2"),
            new InputInteraction("4"),
            new InputInteraction("yenjend"),
            new PrintInteraction("Please re-enter a valid input."),
            new InputInteraction("2"),
            new InputInteraction("z"),
            new PrintInteraction("Please re-enter a valid input."),
            new InputInteraction("4"),
            new InputInteraction("3"),
            new PrintInteraction("      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦         K♣\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 31"),
            new InputInteraction("q"),
            new PrintInteraction("Game quit!\n" +
                    "State of game when quit:\n" +
                    "      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦         K♣\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 31")
    };

    testRun(this.bps, invalid2);
  }

  @Test
  public void testInvalidFromModel() throws IOException {
    //model indicates that a move is invalid
    Interaction[] invalidFromModel = new Interaction[]{
            new InputInteraction("rm1"),
            new InputInteraction("1"),
            new InputInteraction("4"),
            new InputInteraction("Q"),
            new PrintInteraction("Invalid move. Play again. Remove not valid.\n" +
                    "Game quit!\n" +
                    "State of game when quit:\n" +
                    "      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦ 10♠ 3♥  K♣\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 44")
    };
    testRun(this.bps, invalidFromModel);
  }

  @Test
  public void testInvalidFromModel2() throws IOException {
    //model indicates that a move is invalid
    Interaction[] invalidFromModel = new Interaction[]{
            new InputInteraction("rm1"),
            new InputInteraction("1"),
            new InputInteraction("10"),
            new PrintInteraction("Invalid move. Play again. Remove not valid."),
            new InputInteraction("q"),
            new PrintInteraction("Game quit!\nState of game when quit:\n" +
                    "      A♥\n" +
                    "    A♣  A♦\n" +
                    "  A♠  2♥  2♣\n" +
                    "10♦ 10♠ 3♥  K♣\n" +
                    "Draw: 3♦, 3♠\n" +
                    "Score: 44")
    };
    testRun(this.bps, invalidFromModel);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullModel() throws IOException {
    //Should throw illegal argument exception if the model is null
    new PyramidSolitaireTextualController(new StringReader("input"),
            new StringBuilder()).playGame(null, this.deck1, false,
            2, 5);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullReadable() throws IOException {
    //Should throw illegal argument exception if the Readable is null
    PyramidSolitaireTextualController control =
            new PyramidSolitaireTextualController(null,
                    new StringBuilder());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullAppendable() throws IOException {
    //Should throw illegal argument exception if the Appendable is null
    PyramidSolitaireTextualController control =
            new PyramidSolitaireTextualController(new StringReader("input"),
                    null);
  }

  @Test(expected = IllegalStateException.class)
  public void testReadableRunsOut() throws IOException {
    //If Appendable runs out in the middle of a move, should throw an illegal state exception
    Interaction[] readableRunsOut = new Interaction[]{
            new InputInteraction("rm1 "),
            new InputInteraction("4 "),
            new InputInteraction("4 "),
    };
    testRun(this.bps, readableRunsOut);
  }
}

/**
 * @Test(expected = IllegalStateException.class) public void testIllegalStartGameException() {
 * <p>
 * }
 * <p>
 * <p>
 * //How to make a while loop that //"Invalid move. Play again. X" //If the Appendable object is
 * unable to transmit output or the Readable object // is unable to provide inputs (for whatever
 * reason), // the playGame method should throw an IllegalStateException to its caller // }
 **/

