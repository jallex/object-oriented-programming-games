package cs3500.pyramidsolitaire.model.hw02;

/**
 * Represents a type of Card.
 */
public enum Type {
  HEARTS, SPADES, CLUBS, DIAMONDS;
}
